-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 08-Mar-2023 às 12:41
-- Versão do servidor: 5.5.68-MariaDB
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `azcall`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `agente`
--

CREATE TABLE IF NOT EXISTS `agente` (
  `id` int(50) NOT NULL,
  `agente` varchar(20) NOT NULL,
  `pausa` varchar(50) NOT NULL,
  `nota_pausa` text NOT NULL,
  `fila` varchar(30) NOT NULL,
  `pause_bin` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `demanda`
--

CREATE TABLE IF NOT EXISTS `demanda` (
  `id` int(11) NOT NULL,
  `origem` varchar(255) DEFAULT NULL,
  `destino` varchar(255) DEFAULT NULL,
  `assunto` varchar(255) DEFAULT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `urgencia` varchar(255) DEFAULT NULL,
  `data` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `resposta` varchar(255) DEFAULT NULL,
  `protocolo` varchar(255) DEFAULT NULL,
  `setor` varchar(255) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `funcao` varchar(255) NOT NULL,
  `nivel` int(11) NOT NULL,
  `celular` varchar(255) NOT NULL,
  `telefone` varchar(255) NOT NULL,
  `data_cadastro` date NOT NULL,
  `login` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `ramal` varchar(255) NOT NULL,
  `index` varchar(20) DEFAULT NULL,
  `rt-ligacao` varchar(20) DEFAULT NULL,
  `rt-fila` varchar(20) DEFAULT NULL,
  `gr-contatos` varchar(20) DEFAULT NULL,
  `preditivo` varchar(20) DEFAULT NULL,
  `suporte` varchar(20) DEFAULT NULL,
  `admin` varchar(20) NOT NULL,
  `agente` varchar(20) NOT NULL,
  `rtl_sup` int(3) NOT NULL,
  `rtl_ramal` varchar(255) NOT NULL,
  `notas` text
) ENGINE=MyISAM AUTO_INCREMENT=99 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `funcao`, `nivel`, `celular`, `telefone`, `data_cadastro`, `login`, `senha`, `ramal`, `index`, `rt-ligacao`, `rt-fila`, `gr-contatos`, `preditivo`, `suporte`, `admin`, `agente`, `rtl_sup`, `rtl_ramal`, `notas`) VALUES
(95, 'Administrador', '', '', 1, '', '', '2017-05-02', 'admin', 'admin@admin', '', 'index', 'rtl', 'rtf', 'grc', 'DiscP', 'Sup', 'admin', '', 0, '', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agente`
--
ALTER TABLE `agente`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `demanda`
--
ALTER TABLE `demanda`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agente`
--
ALTER TABLE `agente`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `demanda`
--
ALTER TABLE `demanda`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=76;
--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=99;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
